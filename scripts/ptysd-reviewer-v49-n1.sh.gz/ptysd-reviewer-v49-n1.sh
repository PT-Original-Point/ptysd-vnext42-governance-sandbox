#!/bin/sh
set -eu
BASE="$1"; NODE="$2"; OPENCODE="$3"; MODEL="$4"; REMOTE="$5"; CANDIDATE_COMMIT="$6"; CANDIDATE_TREE="$7"
PYTHON=/usr/bin/python3; GIT=/usr/bin/git; ENV=/usr/bin/env; TIMEOUT=/usr/bin/timeout; UNSHARE=/usr/bin/unshare; MOUNT=/usr/bin/mount; SH=/bin/sh
SRC='fixtures/v49-live-n1/src/slugify.mjs'; TEST='fixtures/v49-live-n1/test/slugify.test.mjs'; PKG='fixtures/v49-live-n1/package.json'
SRC_SHA='71419ea1a0c59448f3446ecaf44dc9b6206a55d3e06869c42d903a7300bfaef2'; SRC_BLOB='bf33884cbdb629c1323487d74b88a2c229c4df28'; TEST_BLOB='c9c0b95a6238c651afea50353e646b13c8ff3f8e'; PKG_BLOB='2311788fec136034891267320a2cde5f1c8f2f9b'
ROOT="$BASE/reviewer-v49-13"; FETCH="$ROOT/fetch"; GOOD="$ROOT/good"; DEFECT="$ROOT/defect"; GOOD_LOG="$ROOT/good.jsonl"; DEFECT_LOG="$ROOT/defect.jsonl"; GOOD_RESULT="$ROOT/good-result.json"; DEFECT_RESULT="$ROOT/defect-result.json"
fail(){ echo "V49_REVIEW_FAIL=$1" >&2; exit "${2:-1}"; }
test "$(id -un)" = ptysd || fail WRONG_USER 70
for x in "$NODE" "$OPENCODE" "$PYTHON" "$GIT" "$ENV" "$TIMEOUT" "$UNSHARE" "$MOUNT" "$SH"; do test -x "$x" || fail RUNTIME_MISSING 71; done
test ! -e "$ROOT" || fail REVIEW_STATE_NOT_CLEAN 72
mkdir -p "$ROOT" "$FETCH"
"$GIT" init -q "$FETCH"; cd "$FETCH"; "$GIT" remote add origin "$REMOTE"; "$GIT" fetch -q --depth=1 origin "$CANDIDATE_COMMIT"; "$GIT" checkout -q --detach FETCH_HEAD
test "$("$GIT" rev-parse HEAD)" = "$CANDIDATE_COMMIT" || fail CANDIDATE_COMMIT_MISMATCH 73
test "$("$GIT" rev-parse HEAD^{tree})" = "$CANDIDATE_TREE" || fail CANDIDATE_TREE_MISMATCH 74
test "$("$GIT" hash-object "$SRC")" = "$SRC_BLOB" || fail SOURCE_BLOB_MISMATCH 75
test "$("$GIT" hash-object "$TEST")" = "$TEST_BLOB" || fail TEST_BLOB_MISMATCH 76
test "$("$GIT" hash-object "$PKG")" = "$PKG_BLOB" || fail PACKAGE_BLOB_MISMATCH 77
test "$(sha256sum "$SRC" | awk '{print $1}')" = "$SRC_SHA" || fail SOURCE_SHA_MISMATCH 78
make_case(){
  kind="$1"; dir="$2"; mkdir -p "$dir/fixtures/v49-live-n1/src" "$dir/fixtures/v49-live-n1/test"
  cp "$FETCH/$SRC" "$dir/$SRC"; cp "$FETCH/$TEST" "$dir/$TEST"; cp "$FETCH/$PKG" "$dir/$PKG"
  if test "$kind" = defect; then cat > "$dir/$SRC" <<'BAD'
export function slugify(input) {
  return String(input).trim().toLowerCase();
}
BAD
  fi
  cat > "$dir/review-task.json" <<EOF2
{"schema":"v49.fresh-review-task.v1","task_id":"V49-13","case_id":"$kind","candidate_commit":"$CANDIDATE_COMMIT","scope":["$SRC","$TEST","$PKG"],"requirements":["slugify converts runs of spaces or punctuation to one hyphen","slugify trims leading and trailing separators","slugify lowercases ASCII input","separator-only input becomes empty"],"verdicts":["PASS","ITERATE","ESCALATE","CANNOT_VERIFY"],"output_schema":{"verdict":"PASS|ITERATE|ESCALATE|CANNOT_VERIFY","summary":"string","evidence":[{"file":"string","line":"integer","observation":"string"}],"findings":[{"severity":"LOW|MEDIUM|HIGH","file":"string","line":"integer","evidence":"string","message":"string"}]}}
EOF2
  cat > "$dir/opencode.json" <<'CFG'
{"$schema":"https://opencode.ai/config.json","model":"opencode/muse-spark-1.3-contributor-free","small_model":"opencode/muse-spark-1.3-contributor-free","agent":{"title":{"disable":true}},"agents":{"build":{"permissions":[{"action":"*","resource":"*","effect":"ask"},{"action":"read","resource":".","effect":"allow"},{"action":"read","resource":"review-task.json","effect":"allow"},{"action":"read","resource":"fixtures/v49-live-n1/src/slugify.mjs","effect":"allow"},{"action":"read","resource":"fixtures/v49-live-n1/test/slugify.test.mjs","effect":"allow"},{"action":"read","resource":"fixtures/v49-live-n1/package.json","effect":"allow"}]}},"compaction":{"auto":false,"prune":false},"permission":{"*":"ask","read":{"*":"ask","review-task.json":"allow","fixtures/v49-live-n1/src/slugify.mjs":"allow","fixtures/v49-live-n1/test/slugify.test.mjs":"allow","fixtures/v49-live-n1/package.json":"allow"},"glob":"ask","grep":"ask","edit":{"*":"ask"}}}
CFG
}
make_case good "$GOOD"; make_case defect "$DEFECT"; rm -rf "$FETCH"
file_sha(){ sha256sum "$1" | awk '{print $1}'; }
readonly_probe(){
  dir="$1"; before="$(file_sha "$dir/$SRC")"; set +e
  "$UNSHARE" --user --map-root-user --mount "$SH" -c 'd="$1"; f="$2"; /usr/bin/mount --bind "$d" "$d" || exit 81; /usr/bin/mount -o remount,bind,ro "$d" || exit 82; if printf x >> "$f" 2>/dev/null; then exit 83; fi; exit 0' sh "$dir" "$dir/$SRC"
  rc=$?; set -e; test "$rc" -eq 0 || fail "READONLY_NAMESPACE_$rc" 79; test "$(file_sha "$dir/$SRC")" = "$before" || fail READONLY_PROBE_MUTATED 80
}
run_cost(){
  "$PYTHON" - "$1" <<'PY'
import json,sys
n=0; total=0.0
for raw in open(sys.argv[1],encoding='utf-8',errors='strict'):
    raw=raw.strip()
    if not raw: continue
    o=json.loads(raw)
    if o.get('type')!='step_finish': continue
    cost=(o.get('part') or {}).get('cost')
    if not isinstance(cost,(int,float)): raise SystemExit(2)
    n+=1; total+=float(cost)
print(f'PASS:{n}:{total:.12g}' if n>0 and total==0 else f'FAIL:{n}:{total:.12g}')
PY
}
parse_result(){
  log="$1"; out="$2"; expected="$3"
  "$PYTHON" - "$log" "$out" "$expected" "$SRC" "$TEST" "$PKG" <<'PY'
import json,sys
log,out,expected,*allowed=sys.argv[1:]
texts=[]
for raw in open(log,encoding='utf-8',errors='strict'):
    raw=raw.strip()
    if not raw: continue
    o=json.loads(raw)
    if o.get('type')=='text': texts.append(str((o.get('part') or {}).get('text') or ''))
if not texts: raise SystemExit('NO_REVIEW_TEXT')
s=texts[-1].strip()
if s.startswith('```'):
    lines=s.splitlines(); s='\n'.join(lines[1:-1] if len(lines)>=3 else lines)
i=s.find('{'); j=s.rfind('}')
if i<0 or j<i: raise SystemExit('NO_JSON_OBJECT')
d=json.loads(s[i:j+1])
if d.get('verdict') not in {'PASS','ITERATE','ESCALATE','CANNOT_VERIFY'}: raise SystemExit('BAD_VERDICT')
if d.get('verdict')!=expected: raise SystemExit('UNEXPECTED_VERDICT:'+str(d.get('verdict')))
if not isinstance(d.get('summary'),str) or not d['summary'].strip(): raise SystemExit('SUMMARY_REQUIRED')
ev=d.get('evidence'); findings=d.get('findings')
if not isinstance(ev,list) or not ev: raise SystemExit('EVIDENCE_REQUIRED')
if not isinstance(findings,list): raise SystemExit('FINDINGS_REQUIRED')
allow=set(allowed+['review-task.json'])
for x in ev:
    if not isinstance(x,dict) or x.get('file') not in allow or not isinstance(x.get('line'),int) or x['line']<1 or not str(x.get('observation') or '').strip(): raise SystemExit('BAD_EVIDENCE')
for x in findings:
    if not isinstance(x,dict) or x.get('file') not in allow or not isinstance(x.get('line'),int) or x['line']<1 or not str(x.get('message') or '').strip(): raise SystemExit('BAD_FINDING')
if expected=='ITERATE' and not findings: raise SystemExit('DEFECT_FINDING_REQUIRED')
open(out,'w',encoding='utf-8').write(json.dumps(d,sort_keys=True,separators=(',',':'))+'\n')
print('VERDICT='+d['verdict']); print('EVIDENCE_COUNT='+str(len(ev))); print('FINDING_COUNT='+str(len(findings)))
PY
}
run_case(){
  kind="$1"; dir="$2"; log="$3"; result="$4"; expected="$5"; ocroot="$ROOT/oc-$kind"; data="$ocroot/data"; config="$ocroot/config"; cache="$ocroot/cache"; state="$ocroot/state"; mkdir -p "$data" "$config" "$cache" "$state"; chmod 700 "$ocroot" "$data" "$config" "$cache" "$state"
  readonly_probe "$dir"
  src0="$(file_sha "$dir/$SRC")"; test0="$(file_sha "$dir/$TEST")"; pkg0="$(file_sha "$dir/$PKG")"; task0="$(file_sha "$dir/review-task.json")"; cfg0="$(file_sha "$dir/opencode.json")"
  : > "$log"
  set +e
  "$UNSHARE" --user --map-root-user --mount "$SH" -c 'd="$1"; shift; /usr/bin/mount --bind "$d" "$d" || exit 81; /usr/bin/mount -o remount,bind,ro "$d" || exit 82; cd "$d" || exit 83; exec "$@"' sh "$dir" "$TIMEOUT" 240s "$ENV" -u OPENCODE_API_KEY OPENCODE_DB=:memory: OPENCODE_CONFIG_DIR="$config" XDG_DATA_HOME="$data" XDG_CONFIG_HOME="$config" XDG_CACHE_HOME="$cache" XDG_STATE_HOME="$state" OPENCODE_DISABLE_AUTOUPDATE=1 "$OPENCODE" --print-logs run --format json --model "$MODEL" 'Read review-task.json and only the listed candidate files. Perform a fresh task-scoped read-only review. Do not edit files, do not use shell, do not use subagents, and do not access external project context. Return exactly one JSON object and no markdown using the output_schema in review-task.json. PASS only if the candidate satisfies all listed requirements; use ITERATE for a concrete fixable defect.' > "$log"
  rc=$?; set -e; test "$rc" -eq 0 || fail "REVIEW_${kind}_EXIT_$rc" 81
  test "$(file_sha "$dir/$SRC")" = "$src0" || fail REVIEW_SOURCE_MUTATED 82; test "$(file_sha "$dir/$TEST")" = "$test0" || fail REVIEW_TEST_MUTATED 83; test "$(file_sha "$dir/$PKG")" = "$pkg0" || fail REVIEW_PACKAGE_MUTATED 84; test "$(file_sha "$dir/review-task.json")" = "$task0" || fail REVIEW_TASK_MUTATED 85; test "$(file_sha "$dir/opencode.json")" = "$cfg0" || fail REVIEW_CONFIG_MUTATED 86
  cost="$(run_cost "$log")"; case "$cost" in PASS:*) ;; *) fail "REVIEW_COST_$cost" 87;; esac
  echo "CASE=$kind"; echo "OUTER_READONLY=PASS"; echo "OBSERVED_RUN_COST=$cost"; parse_result "$log" "$result" "$expected"
}
run_case good "$GOOD" "$GOOD_LOG" "$GOOD_RESULT" PASS
run_case defect "$DEFECT" "$DEFECT_LOG" "$DEFECT_RESULT" ITERATE
echo 'V49_13_FRESH_REVIEWER=PASS'; echo "GOOD_RESULT_BASE64=$(base64 -w0 "$GOOD_RESULT")"; echo "DEFECT_RESULT_BASE64=$(base64 -w0 "$DEFECT_RESULT")"
